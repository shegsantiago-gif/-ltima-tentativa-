// onesignal:managed v1
// Centralized OneSignal wrapper — the ONLY place OneSignal SDK calls live
// (except the debug-only verification helper).
package br.com.sg4.gestaoviagens

import android.content.Context
import com.onesignal.OneSignal
import com.onesignal.debug.LogLevel

object OneSignalManager {
    private var initialized = false

    fun initialize(context: Context, appId: String) {
        if (initialized) return
        OneSignal.Debug.logLevel = LogLevel.VERBOSE // remove for production
        OneSignal.initWithContext(context.applicationContext, appId)
        initialized = true
    }

    fun login(externalId: String) = OneSignal.login(externalId)
    fun logout() = OneSignal.logout()
    fun setEmail(email: String) = OneSignal.User.addEmail(email)
    fun setSmsNumber(number: String) = OneSignal.User.addSms(number)
    fun setTag(key: String, value: String) = OneSignal.User.addTag(key, value)
}
