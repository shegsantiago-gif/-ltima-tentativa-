package br.com.sg4.gestaoviagens

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.messaging.FirebaseMessaging
import java.text.NumberFormat
import java.util.Locale

private val Navy = Color(0xFF102743)
private val Gold = Color(0xFFD5AE55)
private val Paper = Color(0xFFF4F6F9)
private val db by lazy { FirebaseFirestore.getInstance() }
private val auth by lazy { FirebaseAuth.getInstance() }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SG4App() }
        // Debug-only OneSignal setup verification (see OneSignalSetupVerification.kt).
        OneSignalSetupVerification.installIfDebug() // onesignal:managed v1
    }
}

data class Trip(
    val id: String = "", val client: String = "", val phone: String = "", val date: String = "",
    val time: String = "", val origin: String = "", val destination: String = "", val passengers: Long = 1,
    val amount: Double = 0.0, val payment: String = "A combinar", val driverUid: String = "",
    val driverName: String = "", val status: String = "Pendente", val notes: String = ""
)

data class Driver(val uid: String, val name: String)

@Composable
fun SG4App() {
    var user by remember { mutableStateOf(auth.currentUser) }
    var role by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Viagens") }
    var trips by remember { mutableStateOf(listOf<Trip>()) }
    var drivers by remember { mutableStateOf(listOf<Driver>()) }
    var showNew by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    LaunchedEffect(user?.uid) {
        val uid = user?.uid
        if (uid != null) FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            db.collection("users").document(uid).update("fcmToken", token)
        }
    }

    DisposableEffect(user?.uid, role) {
        var tripListener: ListenerRegistration? = null
        var profileListener: ListenerRegistration? = null
        if (user != null) {
            profileListener = db.collection("users").document(user!!.uid).addSnapshotListener { s, e ->
                if (e != null) error = e.localizedMessage ?: "Erro ao carregar perfil"
                if (s != null && s.exists()) { role = s.getString("role") ?: "motorista"; displayName = s.getString("name") ?: user!!.email.orEmpty() }
            }
            // Firestore Security Rules não funcionam como filtros: motoristas precisam
            // consultar somente os documentos atribuídos ao próprio UID.
            val tripsQuery = if (role == "admin") {
                db.collection("trips")
            } else {
                db.collection("trips").whereEqualTo("driverUid", user!!.uid)
            }
            tripListener = tripsQuery.addSnapshotListener { s, e ->
                if (e != null) error = e.localizedMessage ?: "Erro ao carregar viagens"
                if (s != null) {
                    trips = s.documents.mapNotNull { d ->
                        val t = d.toObject(Trip::class.java) ?: return@mapNotNull null
                        t.copy(id = d.id)
                    }.sortedBy { it.date + it.time }
                }
            }
            if (role == "admin") db.collection("users").whereEqualTo("role", "motorista").addSnapshotListener { s, _ ->
                if (s != null) drivers = s.documents.map { Driver(it.id, it.getString("name") ?: "Motorista") }
            }
        }
        onDispose { tripListener?.remove(); profileListener?.remove() }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Gold, background = Paper)) {
        if (user == null) LoginScreen(error) { email, password ->
            error = ""
            auth.signInWithEmailAndPassword(email.trim(), password).addOnSuccessListener { user = it.user }
                .addOnFailureListener { error = it.localizedMessage ?: "Não foi possível entrar" }
        }
        else if (role.isBlank()) Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Gold) }
        else {
            Scaffold(containerColor = Paper, topBar = {
                Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 20.dp, vertical = 18.dp)) {
                    Text("SG4 TRANSPORTES E TURISMO", color = Gold, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(if (role == "admin") "Painel do administrador" else "Área do motorista", color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
                }
            }, floatingActionButton = {
                if (role == "admin" && tab == "Viagens") FloatingActionButton(onClick = { showNew = true }, containerColor = Gold, contentColor = Navy) { Icon(Icons.Default.Add, "Nova reserva") }
            }, bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Viagens" to Icons.Default.CalendarMonth, "Resumo" to Icons.Default.Assessment, "Conta" to Icons.Default.Person).forEach { (label, icon) ->
                        NavigationBarItem(selected = tab == label, onClick = { tab = label }, icon = { Icon(icon, null) }, label = { Text(label) })
                    }
                }
            }) { padding ->
                when (tab) {
                    "Viagens" -> TripList(Modifier.padding(padding), trips, role, onStatus = { t, status ->
                        db.collection("trips").document(t.id).update("status", status)
                    })
                    "Resumo" -> SummaryScreen(Modifier.padding(padding), trips, role)
                    else -> AccountScreen(Modifier.padding(padding), displayName, role) { auth.signOut(); user = null; role = "" }
                }
                if (showNew) NewTripDialog(drivers, onDismiss = { showNew = false }, onSave = { trip ->
                    db.collection("trips").add(trip).addOnFailureListener { error = it.localizedMessage ?: "Falha ao salvar" }
                    showNew = false
                })
                if (error.isNotBlank()) AlertDialog(onDismissRequest = { error = "" }, title = { Text("Atenção") }, text = { Text(error) }, confirmButton = { TextButton(onClick = { error = "" }) { Text("OK") } })
            }
        }
    }
}

@Composable
fun LoginScreen(error: String, onLogin: (String, String) -> Unit) {
    var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize().background(Navy).padding(24.dp), contentAlignment = Alignment.Center) {
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("SG4", color = Navy, fontSize = 42.sp, fontWeight = FontWeight.Black)
                Text("GESTÃO DE VIAGENS", color = Gold, fontWeight = FontWeight.Bold)
                OutlinedTextField(email, { email = it }, label = { Text("E-mail") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(password, { password = it }, label = { Text("Senha") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                if (error.isNotBlank()) Text(error, color = Color.Red, fontSize = 12.sp)
                Button(onClick = { onLogin(email, password) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Navy)) { Text("Entrar") }
                Text("Acesso exclusivo para equipe SG4", color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun TripList(modifier: Modifier, trips: List<Trip>, role: String, onStatus: (Trip, String) -> Unit) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Viagens e reservas", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("${trips.size} registro(s)", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        if (trips.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Nenhuma viagem cadastrada.", color = Color.Gray) }
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(trips, key = { it.id }) { t ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(t.client, fontWeight = FontWeight.Bold, color = Navy, modifier = Modifier.weight(1f))
                            StatusChip(t.status)
                        }
                        Text("${t.date} • ${t.time}", color = Gold, fontWeight = FontWeight.Bold)
                        Text("${t.origin}  →  ${t.destination}", fontSize = 13.sp)
                        Text("Passageiros: ${t.passengers}  |  ${money(t.amount)}", color = Color.DarkGray, fontSize = 12.sp)
                        if (role == "admin") Text("Motorista: ${t.driverName.ifBlank { "Não atribuído" }}", fontSize = 12.sp, color = Color.Gray)
                        if (t.phone.isNotBlank()) Text("Contato: ${t.phone}", fontSize = 12.sp, color = Color.Gray)
                        if (t.notes.isNotBlank()) Text("Obs.: ${t.notes}", fontSize = 12.sp)
                        if (role != "admin") {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("A caminho", "Em andamento", "Concluída").forEach { s ->
                                    TextButton(onClick = { onStatus(t, s) }) { Text(s, fontSize = 10.sp) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun StatusChip(status: String) {
    val color = when(status) { "Concluída" -> Color(0xFF26734D); "Cancelada" -> Color(0xFFB3261E); "Em andamento", "A caminho" -> Color(0xFF9A6A00); else -> Color(0xFF536579) }
    Surface(color = color.copy(alpha = .12f), shape = RoundedCornerShape(30.dp)) { Text(status, color = color, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)) }
}

@Composable
fun SummaryScreen(modifier: Modifier, trips: List<Trip>, role: String) {
    val total = trips.sumOf { it.amount }; val done = trips.count { it.status == "Concluída" }; val pending = trips.count { it.status != "Concluída" && it.status != "Cancelada" }
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (role == "admin") "Resumo operacional" else "Meu resumo", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy)
        SummaryCard("Viagens atribuídas / cadastradas", trips.size.toString(), Icons.Default.DirectionsCar)
        SummaryCard("Concluídas", done.toString(), Icons.Default.CheckCircle)
        SummaryCard("Pendentes ou em andamento", pending.toString(), Icons.Default.Schedule)
        if (role == "admin") SummaryCard("Valor total das reservas", money(total), Icons.Default.Payments)
        Text("Os valores representam as reservas registradas, não necessariamente pagamentos recebidos.", color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable fun SummaryCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Gold, modifier = Modifier.size(28.dp)); Spacer(Modifier.width(14.dp)); Column { Text(label, color = Color.Gray, fontSize = 12.sp); Text(value, color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold) } } }
}

@Composable fun AccountScreen(modifier: Modifier, name: String, role: String, logout: () -> Unit) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Minha conta", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("Usuário: $name"); Text("Perfil: ${if (role == "admin") "Administrador" else "Motorista"}")
        Button(onClick = logout, colors = ButtonDefaults.buttonColors(containerColor = Navy)) { Icon(Icons.Default.Logout, null); Spacer(Modifier.width(8.dp)); Text("Sair") }
    }
}

@Composable
fun NewTripDialog(drivers: List<Driver>, onDismiss: () -> Unit, onSave: (Map<String, Any>) -> Unit) {
    var client by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var date by remember { mutableStateOf("") }; var time by remember { mutableStateOf("") }
    var origin by remember { mutableStateOf("") }; var destination by remember { mutableStateOf("") }; var passengers by remember { mutableStateOf("1") }; var amount by remember { mutableStateOf("") }
    var payment by remember { mutableStateOf("A combinar") }; var notes by remember { mutableStateOf("") }; var driver by remember { mutableStateOf<Driver?>(null) }; var expanded by remember { mutableStateOf(false) }; var validation by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Nova reserva", color = Navy, fontWeight = FontWeight.Bold) }, text = {
        Column(Modifier.heightIn(max = 520.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                item { Field("Cliente", client) { client = it } }; item { Field("Telefone / WhatsApp", phone) { phone = it } }; item { Field("Data (DD/MM/AAAA)", date) { date = it } }; item { Field("Horário", time) { time = it } }; item { Field("Origem", origin) { origin = it } }; item { Field("Destino", destination) { destination = it } }
                item { Field("Passageiros", passengers, KeyboardType.Number) { passengers = it } }; item { Field("Valor (R$)", amount, KeyboardType.Decimal) { amount = it } }
                item { Text("Motorista", fontSize = 12.sp, color = Color.Gray); Box { OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(driver?.name ?: "Selecionar motorista") }; DropdownMenu(expanded, { expanded = false }) { drivers.forEach { d -> DropdownMenuItem(text = { Text(d.name) }, onClick = { driver = d; expanded = false }) } } } }
                item { Text("Pagamento", fontSize = 12.sp, color = Color.Gray); var payExpanded by remember { mutableStateOf(false) }; Box { OutlinedButton(onClick = { payExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text(payment) }; DropdownMenu(payExpanded, { payExpanded = false }) { listOf("A combinar", "Pix", "Dinheiro", "Cartão", "Transferência").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { payment = it; payExpanded = false }) } } } }
                item { Field("Observações", notes) { notes = it } }
                if (validation.isNotBlank()) item { Text(validation, color = Color.Red, fontSize = 11.sp) }
            }
        }
    }, confirmButton = { Button(onClick = {
        if (client.isBlank() || date.isBlank() || time.isBlank() || origin.isBlank() || destination.isBlank()) validation = "Preencha cliente, data, horário, origem e destino."
        else onSave(mapOf("client" to client, "phone" to phone, "date" to date, "time" to time, "origin" to origin, "destination" to destination, "passengers" to (passengers.toLongOrNull() ?: 1L), "amount" to ((amount.replace(".", "").replace(",", ".").toDoubleOrNull()) ?: 0.0), "payment" to payment, "driverUid" to (driver?.uid ?: ""), "driverName" to (driver?.name ?: ""), "status" to "Pendente", "notes" to notes))
    }, colors = ButtonDefaults.buttonColors(containerColor = Navy)) { Text("Salvar reserva") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable fun Field(label: String, value: String, keyboard: KeyboardType = KeyboardType.Text, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = keyboard))
}
fun money(value: Double): String = NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(value)
