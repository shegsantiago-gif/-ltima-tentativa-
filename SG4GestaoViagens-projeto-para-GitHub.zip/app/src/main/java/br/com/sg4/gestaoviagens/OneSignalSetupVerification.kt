// onesignal:managed v1
// Debug-only verification helper. BuildConfig.DEBUG ensures this never runs in release.
// Called from MainActivity.onCreate(); safe to keep in the project.
package br.com.sg4.gestaoviagens

import android.util.Log
import com.onesignal.OneSignal
import com.onesignal.user.subscriptions.IPushSubscriptionObserver
import com.onesignal.user.subscriptions.PushSubscriptionChangedState
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object OneSignalSetupVerification {
    private val installed = AtomicBoolean(false)
    private val logged = AtomicBoolean(false)

    fun installIfDebug() {
        if (!BuildConfig.DEBUG) return
        if (!installed.compareAndSet(false, true)) return

        OneSignal.User.pushSubscription.addObserver(object : IPushSubscriptionObserver {
            override fun onPushSubscriptionChange(state: PushSubscriptionChangedState) {
                report(state.current.id)
            }
        })

        // The subscription ID may already exist before the observer is attached.
        report(OneSignal.User.pushSubscription.id)

        // The SDK method is suspend; invoke from a coroutine.
        CoroutineScope(Dispatchers.Main).launch {
            OneSignal.Notifications.requestPermission(false)
        }
    }

    private fun report(subscriptionId: String) {
        if (subscriptionId.isEmpty() || subscriptionId.startsWith("local-")) return
        if (!logged.compareAndSet(false, true)) return
        Log.i("OneSignalVerify", "Push subscription registered: $subscriptionId")
    }
}
