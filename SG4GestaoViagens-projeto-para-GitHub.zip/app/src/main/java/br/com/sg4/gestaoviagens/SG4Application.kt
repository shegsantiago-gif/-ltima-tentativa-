// onesignal:managed v1
// Application subclass — initialize OneSignal at process startup.
package br.com.sg4.gestaoviagens

import android.app.Application

class SG4Application : Application() {
    override fun onCreate() {
        super.onCreate()
        OneSignalManager.initialize(this, "8e020cd0-4eb2-4504-9b5e-415ba4c02cde")
    }
}
