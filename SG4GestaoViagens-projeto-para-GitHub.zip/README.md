# SG4 Gestão de Viagens — Android

Projeto Android nativo em Kotlin + Jetpack Compose, com Firebase Authentication, Cloud Firestore e infraestrutura de notificações push (Firebase Cloud Messaging).

## Perfis planejados
- **Administrador Gerardo**: acesso administrativo completo.
- **Administradora Shirley**: acesso administrativo completo, com as mesmas permissões do Gerardo.
- **Motorista**: visualiza somente as viagens atribuídas ao próprio usuário e pode atualizar o status para A caminho, Em andamento ou Concluída.

O aplicativo diferencia as telas pelo campo `role` do perfil Firebase: `admin` ou `motorista`. Os nomes Gerardo e Shirley são identificações de contas administrativas, não senhas embutidas no aplicativo.

## Reservas e sincronização
- Login por e-mail e senha.
- Administrador cria reservas e atribui motorista.
- Motorista visualiza somente as viagens atribuídas a ele.
- Atualização de status sincronizada pelo Firestore.
- Resumo operacional e financeiro básico.

## Notificações aos motoristas
A base Android já inclui Firebase Messaging, serviço de notificações e registro do token FCM no perfil do usuário. A pasta `functions/` contém uma Cloud Function que envia uma notificação quando uma viagem é atribuída ou transferida para um motorista.

Para ativar as notificações:
1. Ative Firebase Cloud Messaging no projeto Firebase.
2. Faça deploy da função em `functions/` usando Firebase CLI (`npm install` e `firebase deploy --only functions`).
3. Publique as regras de `firestore.rules`.
4. No Android 13 ou superior, permita notificações para o aplicativo nas configurações do aparelho. A solicitação de permissão em tela ainda deve ser adicionada antes da distribuição final.

## Configuração inicial dos dois administradores
1. Crie no Firebase Authentication as contas de Gerardo e Shirley com senhas individuais.
2. Conta de Gerardo: `shegsantiago@gmail.com`.
3. Conta de Shirley: `sg4transportes@gmail.com`.
4. Copie o UID de cada conta.
5. Crie `users/{UID_DO_GERARDO}` com `{ name: "Gerardo Santiago", email: "shegsantiago@gmail.com", role: "admin" }`.
6. Crie `users/{UID_DA_SHIRLEY}` com `{ name: "Shirley", email: "sg4transportes@gmail.com", role: "admin" }`.
7. Crie cada motorista no Authentication e seu perfil Firestore com `{ name: "Nome do Motorista", role: "motorista" }`.

**Segurança:** não coloque senhas no código nem compartilhe senhas pelo aplicativo de mensagens. O endereço de e-mail identifica a conta; a senha deve ser criada diretamente no Firebase Authentication ou por fluxo seguro de redefinição.

**Importante:** o cadastro de usuários novos deve ser provisionado por um administrador no Firebase Authentication e no Firestore. Não habilite escrita pública de perfis/roles: isso permitiria que alguém se promovesse a administrador. A tela de solicitação de cadastro e aprovação dentro do app ainda precisa ser concluída.

## Configuração Firebase
O projeto Firebase informado pelo titular é `sg4-gestao-de-viagens`, com o app Android `br.com.sg4.gestaoviagens`. O arquivo `app/google-services.json` já está incluído neste pacote. Authentication por e-mail/senha e Cloud Firestore foram informados como ativados/criados pelo titular. Ainda é necessário publicar as regras abaixo e provisionar as contas de usuário. Nunca compartilhe senhas Google/Firebase.

## Gerar APK
1. Instale Android Studio atualizado e abra esta pasta como projeto.
2. Crie um projeto Firebase e adicione um app Android com pacote `br.com.sg4.gestaoviagens`.
3. Ative Authentication > E-mail/senha e crie Cloud Firestore.
4. Baixe `google-services.json` e coloque em `app/google-services.json`.
5. Publique `firestore.rules` e faça deploy de `functions/`.
6. Sincronize o Gradle e use Build > Build Bundle(s) / APK(s) > Build APK(s).

O APK de depuração será gerado em `app/build/outputs/apk/debug/app-debug.apk`. Para distribuir a equipe, gere uma versão `release` assinada.

## Estado do projeto
É um projeto-fonte inicial com a configuração Firebase Android recebida e consultas de viagens compatíveis com regras de segurança. Ainda requer publicação das regras, provisionamento das contas, implementação da tela de cadastro/aprovação dentro do aplicativo, implantação e teste das notificações, testes em aparelhos e compilação/assinatura do APK. Não distribuir como versão de produção antes dessas etapas e da revisão das regras de segurança.

## Configuração Firebase recebida (11/11/2026)
O arquivo `app/google-services.json` foi incluído com os dados fornecidos para o projeto `sg4-gestao-de-viagens` e pacote `br.com.sg4.gestaoviagens`. A sintaxe JSON foi validada.

Ainda é necessário, no Console Firebase:
- Publicar `firestore.rules` (Firestore Database > Regras > publicar).
- Criar as contas de Gerardo e Shirley em Authentication > Users e os documentos correspondentes em `users/{UID}` com `role: admin`.
- Criar motoristas em Authentication e os respectivos documentos `users/{UID}` com `role: motorista`.
- Implantar a Cloud Function em `functions/` para notificações de atribuição (verificar o plano de faturamento exigido pelo Firebase para Cloud Functions).
- Testar em dois ou mais aparelhos antes de distribuir o aplicativo.

As consultas do aplicativo foram ajustadas para que motoristas consultem somente viagens com `driverUid` igual ao próprio UID, compatível com as regras do Firestore.

## Limitações atuais
Este pacote contém a configuração Firebase Android, mas ainda não é um APK compilado. A tela administrativa de cadastro/aprovação de motoristas e os testes de ponta a ponta de autenticação, Firestore e notificações ainda precisam ser concluídos. O ambiente de preparação não dispõe de Gradle/Android SDK para gerar e testar o APK aqui.
