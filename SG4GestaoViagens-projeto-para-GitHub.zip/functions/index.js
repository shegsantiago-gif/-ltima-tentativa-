const { onDocumentWritten } = require('firebase-functions/v2/firestore');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');
const { getMessaging } = require('firebase-admin/messaging');

initializeApp();

// Envia push quando uma viagem é atribuída ou transferida para um motorista.
exports.notifyDriverOnTripAssignment = onDocumentWritten('trips/{tripId}', async (event) => {
  const before = event.data.before.exists ? event.data.before.data() : null;
  const after = event.data.after.exists ? event.data.after.data() : null;
  if (!after || !after.driverUid) return;
  if (before && before.driverUid === after.driverUid) return;

  const userDoc = await getFirestore().collection('users').doc(after.driverUid).get();
  const token = userDoc.get('fcmToken');
  if (!token) return;

  const date = after.date || 'Data a confirmar';
  const time = after.time || 'Horário a confirmar';
  const origin = after.origin || 'Origem';
  const destination = after.destination || 'Destino';
  await getMessaging().send({
    token,
    notification: {
      title: 'Nova viagem atribuída – SG4',
      body: `${date} às ${time}: ${origin} → ${destination}`
    },
    data: { tripId: event.params.tripId, title: 'Nova viagem atribuída – SG4' }
  });
});
